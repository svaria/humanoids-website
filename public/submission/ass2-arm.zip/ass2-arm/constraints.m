% This function is the constraints to get from p0 to pregrasp
function [ineq_violations, eq_violations] = constraints(p)

global x_d;
pos = fk(p);
step = 0.0125;
% let the pregrasp be 0.0125 units down in y direction
% and the necessary calculated amount, lm, (to maintain angle)
% in the x direction
lm = step*tan(x_d(3));
eq_violations(1) = pos(1) - x_d(1)+step;
eq_violations(2) = pos(2) - x_d(2)+lm;
eq_violations(3) = pos(3) - x_d(3);

ineq_violations = [];
end