function [score] = criterion(p)
global x_d p_d moves scores;
score = (p-p_d)'*(p-p_d);
moves = [moves;p'];

end