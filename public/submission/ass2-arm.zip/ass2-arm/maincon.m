% optimize assignment inverse kinematics
% using constraints

global x_d p_d lb ub moves;

x_d
p_d
p0

% set options for fmincon()
% options = optimset('Display','iter','MaxFunEvals',1000000,'Algorithm','interior-point');
options = optimset('Display','iter','MaxFunEvals',100000,'Algorithm','sqp');

% do optimization to get to pregrasp
[answer,fval,exitflag]=fmincon(@criterion,p0,[],[],[],[],lb,ub,@constraints,options);

% The pregrasp location is simply the last move so far
pregraspMove = moves(end,:);
answer
fval
exitflag

%do optimization from pregrasp to grasp
[answer2,fval2,exitflag2] = fmincon(@criterion,p0,[],[],[],[],lb,ub,@constraints2,options);
% the grasp location is simply the last move in the array
graspMove = moves(end,:);
% smooth trajectory to pregrasp move
for i = 0:9,
    draw(p0' + (pregraspMove-p0')*((i+1)/10));
    pause(0.1);
end

% smooth trajectory from pregrasp to grasp
for i = 0:3,
    draw(pregraspMove + (graspMove-pregraspMove)*((i+1)/4));
    pause(0.1);
end
